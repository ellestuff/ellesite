SMODS.Atlas {
	key = "jokers",
	path = "jokers.png",
	px = 71,
	py = 95,
}

loc_colour('red')
G.ARGS.LOC_COLOURS['ellejokers_elle'] = HEX('FF53A9')

local caption = '{C:ellejokers_elle,s:0.7,E:1}'

SMODS.Joker {
	key = 'cheshire',
	loc_txt = {
		name = 'Cheshire',
		text = {
			"If {C:attention}first hand{} of round",
			"has a single card, destroy",
			"it and gain {X:mult,C:white}X#1#{} Mult",
			"{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
			" ",
			caption.."Looks hungry. Maybe get a little closer..."
		}
	},
	config = { extra = { Xmult_mod = 0.1, Xmult = 1 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.Xmult_mod, card.ability.extra.Xmult } }
	end,
	rarity = 3,
	atlas = 'jokers',
	pos = { x = 0, y = 0 },
	cost = 8,
	calculate = function(self, card, context)
		if context.destroying_card and G.GAME.current_round.hands_played == 0 and not context.blueprint and #context.full_hand == 1 then
			if context.cardarea == G.play then
				card.ability.extra.Xmult = card.ability.extra.Xmult + card.ability.extra.Xmult_mod
				local _card = context.full_hand[1]
				
				_card:remove_from_deck(_card)
				local _texts = {"GLLP~", "Yum~", "UURP~", "Nom~", "Tasty~"}
				return {
					message_card = card,
					remove = true,
					message = _texts[math.random(5)]
				}
			end
		end
		if context.joker_main then
			if card.ability.extra.Xmult ~= 0 then
				return {
					Xmult_mod = card.ability.extra.Xmult,
					message = localize { type = 'variable', key = 'a_xmult', vars = { card.ability.extra.Xmult } }
				}
			end
		end
	end
}

SMODS.Joker {
	key = 'furry',
	loc_txt = {
		name = '"Chloe"',
		text = {
			"This joker gains {C:mult}+#1#{} Mult",
			"every time a card",
			"is destroyed",
			"{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)",
			" ",
			caption.."Something about her seems off..."
		}
	},
	config = { extra = { mult_mod = 5, mult = 0 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult_mod, card.ability.extra.mult } }
	end,
	rarity = 2,
	atlas = 'jokers',
	pos = { x = 1, y = 0 },
	cost = 5,
	calculate = function(self, card, context)
		if context.remove_playing_cards then
			local _mult = card.ability.extra.mult_mod * #context.removed
			card.ability.extra.mult = card.ability.extra.mult + _mult
			return {
				message = "Nice~ (+"..(_mult)..")"
			}
		end
		if context.joker_main then
			if card.ability.extra.mult ~= 0 then
				return {
					mult_mod = card.ability.extra.mult,
					message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
				}
			end
		end
	end
}

SMODS.Joker {
	key = 'sophie',
	loc_txt = {
		name = 'Sophie',
		text = {
			"This joker gains {C:mult}+#1#{} Mult",
			"for each multiple of",
			"{C:attention}Round Score{} reached",
			"at end of round",
			"{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)",
			" ",
			caption.."It burns so good~"
		}
	},
	config = { extra = { mult_mod = 4, mult = 0 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult_mod, card.ability.extra.mult } }
	end,
	rarity = 2,
	atlas = 'jokers',
	pos = { x = 2, y = 0 },
	cost = 6,
	calculate = function(self, card, context)
		if context.end_of_round and context.cardarea == G.jokers then
			local _mult = math.floor(G.GAME.chips / G.GAME.blind.chips) * card.ability.extra.mult_mod
			card.ability.extra.mult = card.ability.extra.mult + _mult
			return {
				message = "Hehe~ (+".._mult..")"
			}
		end
		if context.joker_main then
			if card.ability.extra.mult ~= 0 then
				return {
					mult_mod = card.ability.extra.mult,
					message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
				}
			end
		end
	end
}