return {
	--["silly_mode"] = false
}